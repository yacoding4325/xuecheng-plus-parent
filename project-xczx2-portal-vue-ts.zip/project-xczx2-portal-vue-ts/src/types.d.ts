declare const AliyunUpload: any
